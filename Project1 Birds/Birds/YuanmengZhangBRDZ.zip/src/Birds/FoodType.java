package Birds;

public enum FoodType {
    BERRIES,
    SEEDS,
    FRUIT,
    INSECTS,
    OTHERBIRDS,
    EGGS,
    SMALLMAMMALS,
    FISH,
    BUDS,
    LARVAE,
    AQUATICINVERTEBRATES,
    NUTS,
    VEGETATION
}
